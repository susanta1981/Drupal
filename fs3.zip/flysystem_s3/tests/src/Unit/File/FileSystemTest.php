<?php

namespace NoDrupal\Tests\flysystem_s3\Unit\File;

use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Site\Settings;
use Drupal\flysystem_s3\File\FileSystem;
use Drupal\Tests\UnitTestCase;
use org\bovigo\vfs\vfsStream;
use Prophecy\Argument;

/**
 * Tests the filesystem decorator to handle chmod().
 *
 * @coversDefaultClass \Drupal\flysystem_s3\File\FileSystem
 *
 * @group flysystem_s3
 */
class FileSystemTest extends UnitTestCase {

  /**
   * Test that we pass public files straight through to chmod().
   */
  public function testPublicChmod() {
    $settings = new Settings([
      'flysystem' => [
        's3' => [
          'driver' => 's3',
          'config' => [
            'options' => [
              'ACL' => 'public-read',
            ],
          ],
        ],
      ],
    ]);
    $decorated = $this->prophesize(FileSystemInterface::class);
    $decorated->uriScheme(Argument::type('string'))->willReturn('s3');
    $decorated->chmod('s3://test.txt', NULL)->willReturn(TRUE);
    $decorated = $decorated->reveal();
    $filesystem = new FileSystem($settings, $decorated);
    $this->assertTrue($filesystem->chmod('s3://test.txt'));
  }

  /**
   * Test that private files are chmod'ed correctly.
   */
  public function testPrivateChmod() {
    $structure = [
      'test.txt' => 'test file',
      'directory' => [],
    ];
    $root = vfsStream::setup('s3', NULL, $structure);

    $settings = new Settings([
      'flysystem' => [
        'vfs' => [
          'driver' => 's3',
          'config' => [
            'options' => [
              'ACL' => 'private',
            ],
          ],
        ],
      ],
    ]);
    $decorated = $this->prophesize(FileSystemInterface::class);
    $decorated->uriScheme(Argument::type('string'))->willReturn('vfs');
    $decorated->chmod('vfs://s3/test.txt', 0600)->willReturn(TRUE);
    $decorated->uriScheme(Argument::type('string'))->willReturn('vfs');
    $decorated->chmod('vfs://s3/directory', 0700)->willReturn(TRUE);
    $decorated = $decorated->reveal();

    $filesystem = new FileSystem($settings, $decorated);
    $this->assertTrue($filesystem->chmod(vfsStream::url('s3/test.txt')));
    $this->assertTrue($filesystem->chmod(vfsStream::url('s3/directory')));
  }

}
