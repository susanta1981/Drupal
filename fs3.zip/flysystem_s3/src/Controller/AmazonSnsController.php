<?php

namespace Drupal\flysystem_s3\Controller;

use Aws\Sns\Exception\InvalidSnsMessageException;
use Aws\Sns\Message;
use Aws\Sns\MessageValidator;
use Drupal\Component\Serialization\Json;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Respond to SNS notifications sent by Amazon.
 */
class AmazonSnsController {

  /**
   * Controller callback to process an SNS notification.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request object.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The response. Typically SNS will resend if the response is not a 2XX.
   *
   * @throws \RuntimeException
   *   Thrown when required headers are missing or the message does not
   *   validate.
   */
  public function receive(Request $request) {
    // Instantiate the Message and Validator
    // TODO: Validate SNS topic
    // Make sure the SNS-provided header exists.
    if (!isset($request->headers) || !$request->headers->get('X_AMZ_SNS_MESSAGE_TYPE')) {
      throw new \RuntimeException('SNS message type header not provided');
    }

    $data = Json::decode($request->getContent());
    // TODO: Catch InvalidArgument.
    $message = new Message($data);
    $validator = new MessageValidator();

    // Validate the message and log errors if invalid.
    try {
      $validator->validate($message);
    }
    catch (InvalidSnsMessageException $e) {
      throw new \RuntimeException('Message not accepted');
    }

    // Check the type of the message and handle the subscription.
    if ($message['Type'] === 'SubscriptionConfirmation') {
      // Confirm the subscription by sending a GET request to the SubscribeURL.
      file_get_contents($message['SubscribeURL']);
    }

    if ($message['Type'] == 'Notification') {
      $n = Json::decode($message['Message']);
      foreach ($n['Records'] as $record) {
        if ($record['eventSource'] == 'aws:s3' && $record['eventName'] == 'ObjectRemoved:Delete') {
          $s3 = $record['s3'];
          $bucket = $s3['bucket']['name'];
          $object = $s3['object']['key'];
          $schemes = \Drupal::service('flysystem_factory')->getSchemes();
          foreach ($schemes as $scheme) {
            $settings = \Drupal::service('flysystem_factory')->getSettings($scheme);
            if ($settings['driver'] == 's3' && $settings['config']['bucket'] == $bucket) {
              $uri = $scheme . '://' . $object;
              /** @var \Drupal\Core\Entity\EntityStorageInterface $s */
              $s = \Drupal::service('entity_type.manager')->getStorage('file');
              $files = $s->loadByProperties(['uri' => $uri]);
              if (!empty($files)) {
                $file = reset($files);
                $file->delete();
              }
            }
          }
        }
      }
    }

    // We've successfully processed the response, so return a 200 so SNS doesn't
    // retry the notification.
    return new Response();
  }

}
