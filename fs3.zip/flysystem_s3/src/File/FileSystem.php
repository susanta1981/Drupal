<?php

namespace Drupal\flysystem_s3\File;

use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Site\Settings;
use Psr\Log\LoggerInterface;

/**
 * Decorates the Drupal FileSystem service to handle chmod() for S3.
 */
class FileSystem implements FileSystemInterface {

  /**
   * The site settings.
   *
   * @var \Drupal\Core\Site\Settings
   */
  protected $settings;

  /**
   * The file system being decorated.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * FileSystem constructor.
   *
   * @param \Drupal\Core\Site\Settings $settings
   *   The site settings.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system being decorated.
   */
  public function __construct(Settings $settings, FileSystemInterface $file_system) {
    $this->settings = $settings;
    $this->fileSystem = $file_system;
  }

  /**
   * Implement chmod(), respecting S3's ACL setting.
   *
   * With Drupal's private files, chmod() is called by file_save_upload() to
   * ensure the new file is readable by the file server, using the same file
   * system permissions as the public file system. However, since private files
   * are stored outside of the docroot, they are forced to go be accessed
   * through Drupal's file permissions handling.
   *
   * With S3, \Twistor\FlysystemStreamWrapper::stream_metadata() automatically
   * maps chmod() calls to basic S3 ACLs, which means that while a file can be
   * initially uploaded as 'private', Drupal will immediately chmod it to
   * public using the default file mask in settings.php.
   *
   * This method checks to see if we are using a private S3 scheme, and if so,
   * ensures that group / other permissions are always unset, ensuring the
   * stream wrapper preserves private permissions.
   *
   * @param string $uri
   *   A string containing a URI file, or directory path.
   * @param int $mode
   *   Integer value for the permissions. Consult PHP chmod() documentation for
   *   more information.
   *
   * @return bool
   *   TRUE for success, FALSE in the event of an error.
   *
   * @see \Twistor\FlysystemStreamWrapper::stream_metadata
   */
  public function chmod($uri, $mode = NULL) {
    $scheme = $this->fileSystem->uriScheme($uri);

    if ($this->isPrivateS3Scheme($scheme)) {
      is_dir($uri) ? $mode = 0700 : $mode = 0600;
    }

    return $this->fileSystem->chmod($uri, $mode);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function moveUploadedFile($filename, $uri) {
    return $this->fileSystem->moveUploadedFile($filename, $uri);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function unlink($uri, $context = NULL) {
    return $this->fileSystem->unlink($uri, $context);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function realpath($uri) {
    return $this->fileSystem->realpath($uri);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function dirname($uri) {
    return $this->fileSystem->dirname($uri);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function basename($uri, $suffix = NULL) {
    return $this->fileSystem->basename($uri, $suffix);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function mkdir($uri, $mode = NULL, $recursive = FALSE, $context = NULL) {
    return $this->fileSystem->mkdir($uri, $mode, $recursive, $context);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function rmdir($uri, $context = NULL) {
    return $this->fileSystem->rmdir($uri, $context);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function tempnam($directory, $prefix) {
    return $this->fileSystem->tempnam($directory, $prefix);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function uriScheme($uri) {
    return $this->fileSystem->uriScheme($uri);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public function validScheme($scheme) {
    return $this->fileSystem->validScheme($scheme);
  }

  /**
   * Return if a scheme is a private S3 scheme.
   *
   * @param string $scheme
   *   The scheme to check.
   *
   * @return bool
   *   TRUE if the scheme's S3 acl is set to 'private'.
   */
  protected function isPrivateS3Scheme($scheme) {
    $settings = $this->settings->get('flysystem', []);
    return isset($settings[$scheme])
      && $settings[$scheme]['driver'] == 's3'
      && isset($settings[$scheme]['config']['options']['ACL'])
      && $settings[$scheme]['config']['options']['ACL'] == 'private';
  }

}
