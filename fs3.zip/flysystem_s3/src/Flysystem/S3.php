<?php

namespace Drupal\flysystem_s3\Flysystem;

use Aws\AwsClientInterface;
use Aws\Credentials\Credentials;
use Aws\S3\Exception\S3Exception;
use Aws\S3\S3Client;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Logger\RfcLogLevel;
use Drupal\Core\PageCache\ResponsePolicy\KillSwitch;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Utility\Error;
use Drupal\flysystem\Plugin\FlysystemPluginInterface;
use Drupal\flysystem\Plugin\FlysystemUrlTrait;
use Drupal\flysystem\Plugin\ImageStyleGenerationTrait;
use Drupal\flysystem_s3\AwsCacheAdapter;
use Drupal\flysystem_s3\Flysystem\Adapter\S3Adapter;
use League\Flysystem\AdapterInterface;
use League\Flysystem\Config;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Drupal plugin for the "S3" Flysystem adapter.
 *
 * @Adapter(id = "s3")
 */
class S3 implements FlysystemPluginInterface, ContainerFactoryPluginInterface {

  use ImageStyleGenerationTrait;
  use FlysystemUrlTrait { getExternalUrl as getDownloadlUrl; }

  /**
   * The S3 bucket.
   *
   * @var string
   */
  protected $bucket;

  /**
   * The S3 client.
   *
   * @var \Aws\S3\S3ClientInterface
   */
  protected $client;

  /**
   * Options to pass into \League\Flysystem\AwsS3v3\AwsS3Adapter.
   *
   * @var array
   */
  protected $options;

  /**
   * The path prefix inside the bucket.
   *
   * @var string
   */
  protected $prefix;

  /**
   * The URL prefix.
   *
   * @var string
   */
  protected $urlPrefix;

  /**
   * The amount of time presigned URLs are valid for, such as '+60 seconds'.
   *
   * @var string
   */
  protected $expires;

  /**
   * The Drupal renderer used to set cache expiration.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The system logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * The kill switch response policy.
   *
   * @var \Drupal\Core\PageCache\ResponsePolicy\KillSwitch
   */
  protected $killSwitch;

  /**
   * Constructs an S3 object.
   *
   * @param \Aws\AwsClientInterface $client
   *   The AWS client.
   * @param \League\Flysystem\Config $config
   *   The configuration.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The Drupal renderer used to set cache expiration.
   * @param \Psr\Log\LoggerInterface $logger
   *   The system logger.
   * @param \Drupal\Core\PageCache\ResponsePolicy\KillSwitch $kill_switch
   *   (optional) Service to disable page caching when presigned URLs are used.
   */
  public function __construct(AwsClientInterface $client, Config $config, RendererInterface $renderer, LoggerInterface $logger, KillSwitch $kill_switch = NULL) {
    $this->client = $client;
    $this->bucket = $config->get('bucket', '');
    $this->prefix = $config->get('prefix', '');
    $this->options = $config->get('options', []);
    $this->expires = $config->get('expires');

    $this->urlPrefix = $this->calculateUrlPrefix($config);

    $this->renderer = $renderer;
    $this->logger = $logger;
    $this->killSwitch = $kill_switch;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $configuration = static::mergeConfiguration($container, $configuration);
    $client_config = static::mergeClientConfiguration($container, $configuration);

    $client = S3Client::factory($client_config);

    unset($configuration['key'], $configuration['secret']);

    return new static($client, new Config($configuration), $container->get('renderer'), $container->get('logger.channel.flysystem'));
  }

  /**
   * Returns an S3 client configuration based on a Flysystem configuration.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container to pull out services used in the plugin.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   *
   * @return array
   *   The client configuration.
   */
  public static function mergeClientConfiguration(ContainerInterface $container, array $configuration) {
    $client_config = [
      'version' => 'latest',
      'region' => $configuration['region'],
      'endpoint' => $configuration['endpoint'],
    ];

    // Allow authentication with standard secret/key or IAM roles.
    if (isset($configuration['key']) && isset($configuration['secret'])) {
      $client_config['credentials'] = new Credentials($configuration['key'], $configuration['secret']);

      return $client_config;
    }

    $client_config['credentials.cache'] = new AwsCacheAdapter(
      $container->get('cache.default'),
      'flysystem_s3:'
    );

    return $client_config;
  }

  /**
   * Merges default Flysystem configuration.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container to pull out services used in the plugin.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   *
   * @return array
   *   The Flysystem configuration.
   */
  public static function mergeConfiguration(ContainerInterface $container, array $configuration) {
    $protocol = $container->get('request_stack')
      ->getCurrentRequest()
      ->getScheme();

    return $configuration += [
      'protocol' => $protocol,
      'region' => 'us-east-1',
      'endpoint' => NULL,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getAdapter() {
    return new S3Adapter($this->client, $this->bucket, $this->prefix, $this->options);
  }

  /**
   * {@inheritdoc}
   */
  public function getExternalUrl($uri) {
    $target = $this->getTarget($uri);

    if (strpos($target, 'styles/') === 0 && !file_exists($uri)) {
      return $this->generateImageUrl($target);
    }

    // This method can only return FALSE if the wrapper does not exist, and not
    // if there is an error in generating the URL. If an asset is missing on S3,
    // then the getVisibility() call will throw an exception. In that case,
    // we log it and return an unsigned URL so we don't break the expected
    // return or completely break the response.
    try {
      if ($this->getAdapter()->getVisibility($target)['visibility'] == AdapterInterface::VISIBILITY_PRIVATE && $this->expires) {
        // Use getCommand() so we don't actually make a request yet.
        $command = $this->client->getCommand('getObject', [
          'Bucket' => $this->bucket,
          'Key' => $target,
        ]);
        $request = $this->client->createPresignedRequest($command, $this->expires);

        // This informs the render system that the request has a cache
        // dependency on the time this URL is valid for.
        // TODO: The page cache does not currently respect max-age cache
        // headers. We can't set proper max-age based on the signing time until
        // https://www.drupal.org/node/2352009 is fixed. Unfortunately, this
        // also means we can't cache any pages with signed URLs at all. When we
        // can implement this, we should parse out max-age from the generated
        // URL as suggested at https://github.com/aws/aws-sdk-php/issues/1052.
        $build = [
          '#cache' => [
            'max-age' => 0,
          ],
        ];
        $this->renderer->render($build);

        // Since the above bug means this max-age isn't respected, we have to
        // kill the general page cache.
        if ($this->killSwitch) {
          $this->killSwitch->trigger();
        }

        return (string) $request->getUri();
      }
    }
    catch (S3Exception $e) {
      // Inline watchdog_exception() so we can use it with our injected service.
      // Use a default value if $message is not set.
      $message = '%type: @message in %function (line %line of %file).';
      $variables = Error::decodeException($e);

      $this->logger->error($message, $variables);
    }

    return $this->urlPrefix . '/' . UrlHelper::encodePath($target);
  }

  /**
   * {@inheritdoc}
   */
  public function ensure($force = FALSE) {
    // @TODO: If the bucket exists, can we write to it? Find a way to test that.
    if (!$this->client->doesBucketExist($this->bucket)) {
      return [[
        'severity' => RfcLogLevel::ERROR,
        'message' => 'Bucket %bucket does not exist.',
        'context' => [
          '%bucket' => $this->bucket,
        ],
      ]];
    }

    return [];
  }

  /**
   * Calculates the URL prefix.
   *
   * @param \League\Flysystem\Config $config
   *   The configuration.
   *
   * @return string
   *   The URL prefix in the form protocol://cname[/bucket][/prefix].
   */
  private function calculateUrlPrefix(Config $config) {
    $protocol = $config->get('protocol', 'http');

    $cname = (string) $config->get('cname');

    $prefix = (string) $config->get('prefix', '');
    $prefix = $prefix === '' ? '' : '/' . UrlHelper::encodePath($prefix);

    if ($cname !== '' && $config->get('cname_is_bucket', TRUE)) {
       return $protocol . '://' . $cname . $prefix;
     }

    $bucket = (string) $config->get('bucket', '');
    $bucket = $bucket === '' ? '' : '/' . UrlHelper::encodePath($bucket);

    // No custom CNAME was provided. Generate the default S3 one.
    if ($cname === '') {
      $cname = 's3-' . $config->get('region', 'us-east-1') . '.amazonaws.com';
    }

    // us-east-1 doesn't follow the consistent mapping.
    if ($cname === 's3-us-east-1.amazonaws.com') {
      $cname = 's3.amazonaws.com';
    }

    return $protocol . '://' . $cname . $bucket . $prefix;
  }

}
