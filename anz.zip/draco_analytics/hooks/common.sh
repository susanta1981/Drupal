#!/usr/bin/env bash

# Add our vendor bin directory to the path
PATH=$(pwd)/vendor/bin:$PATH

bootstrap() {
  # Install composer
  mkdir -p vendor/bin
  if [ -f vendor/bin/composer ]
  then
    composer selfupdate
  else
    curl -sS https://getcomposer.org/installer | php -- --filename vendor/bin/composer
  fi

  # Install robo.
  if [ ! -f vendor/bin/robo ]
  then
    echo "Robo is pinned to 0.7.2 until https://github.com/Codegyre/Robo/issues/333 is resolved."
    curl -L -sS https://github.com/deviantintegral/Robo/releases/download/0.7.2/robo.phar > vendor/bin/robo
    chmod +x vendor/bin/robo
  fi
}
