#!/usr/bin/env bash

# Common setup needed for every hook.

source ./hooks/common.sh

bootstrap
