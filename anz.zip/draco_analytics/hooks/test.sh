#!/bin/bash -ex

# Jenkins test.sh hook implementation.

source ./hooks/common.sh

bootstrap

export SIMPLETEST_BASE_URL="http://localhost"
export SIMPLETEST_DB="sqlite://localhost//tmp/drupal.sqlite"
export BROWSERTEST_OUTPUT_DIRECTORY="/var/www/html/sites/simpletest"

# This is the command used by the base image to serve Drupal.
apache2-foreground&

robo setup:skeleton

# Run phantom for functional javascript tests.
# Disabled until we rebuild phantomjs master to see if
# https://github.com/ariya/phantomjs/issues/12750 is resolved.
# We need to || true here so the failed email doesn't cause the hook to exit.
# TODO this can probably be part of the robo setup.
# sudo -E -u www-data ../../vendor/bin/drush si -y --db-url=$SIMPLETEST_DB minimal || true
# phantomjs --ssl-protocol=any --debug=true --ignore-ssl-errors=true --cookies-file=/tmp/cookies.txt ../../vendor/jcalderonzumba/gastonjs/src/Client/main.js 8510 1024 768 &
sudo -E -u www-data vendor/bin/robo test || true

# www-data doesn't have permission to the module directory, so we copy results
# after the test has run.
cp /tmp/junit-results.xml .
