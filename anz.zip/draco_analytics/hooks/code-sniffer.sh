#!/bin/bash -ex

# Runs CodeSniffer checks on a Drupal module.

source ./hooks/common.sh

bootstrap

# Install dependencies and configure phpcs
robo setup:skeleton
../../vendor/bin/phpcs --config-set installed_paths $(realpath ../../vendor/drupal/coder/coder_sniffer)

# Check coding standards
../../vendor/bin/phpcs --standard=Drupal --extensions=php,module,inc,install,test,profile,theme,css,info --ignore=vendor .

# Check best practices
../../vendor/bin/phpcs --standard=DrupalPractice --extensions=php,module,inc,install,test,profile,theme,css,info --ignore=vendor .
