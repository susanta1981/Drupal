<?php

namespace Drupal\Test\draco_analytics\Unit;

use \Drupal\draco_analytics\DataLayer;
use Drupal\Tests\UnitTestCase;

/**
 * Tests \Drupal\draco_analytics\DataLayer.
 *
 * @class DataLayerTest
 *
 * @package Drupal\draco_analytics\Tests
 *
 * @coversDefaultClass \Drupal\draco_analytics\DataLayer
 *
 * @group draco_analytics
 */
class DataLayerTest extends UnitTestCase {

  /**
   * The Data Layer object.
   *
   * @var DataLayer
   */
  protected $dataLayer;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
    $this->dataLayer = new DataLayer();
  }

  /**
   * Test empty tags.
   *
   * @covers ::__construct
   * @covers ::getDefaults
   * @covers ::get
   */
  public function testEmpty() {
    $dlData = $this->dataLayer->get();

    $empty = [
      'section' => [
        '',
        '',
      ],
    ];
    $this->assertArrayEquals($empty, $dlData, 'Egads!  Array is not empty!');
  }

  /**
   * Test Video inclusion.
   *
   * @covers ::addVideo
   * @covers ::get
   */
  public function testVideo() {
    $dlData = $this->dataLayer->addVideo()->get();

    $this->assertEquals(1, $dlData['video_count'], 'Egads!  Video count is not 1!');
    $this->assertEquals(TRUE, $dlData['video_present'], 'Egads!  Video present is not TRUE!');
  }

  /**
   * Test single string inclusion.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testSingleAddString() {
    $add = [$this->randomMachineName() => $this->randomMachineName()];
    $this->addAndCheck($add);
  }

  /**
   * Test single int inclusions.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testSingleAddInts() {
    $add = [$this->randomMachineName() => mt_rand(1, PHP_INT_MAX)];
    $this->addAndCheck($add);

    $add = [$this->randomMachineName() => mt_rand(PHP_INT_MIN, -1)];
    $this->addAndCheck($add);
  }

  /**
   * Test multiple mixed value inclusions.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testMultipleAdds() {
    $k = $this->randomMachineName();
    $add = [
      $k . '_0' => mt_rand(1, PHP_INT_MAX),
      $k . '_1' => mt_rand(PHP_INT_MIN, -1),
      $k . '_2' => $this->randomMachineName(),
      $k . '_3' => mt_rand(1, PHP_INT_MAX),
      $k . '_4' => mt_rand(PHP_INT_MIN, -1),
      $k . '_5' => $this->randomMachineName(),
      $k . '_6' => mt_rand(1, PHP_INT_MAX),
      $k . '_7' => mt_rand(PHP_INT_MIN, -1),
      $k . '_8' => $this->randomMachineName(),
    ];
    $this->addAndCheck($add);
  }

  /**
   * Test multiple adds for the same key.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testMultipleSameKeyAdds() {
    $k = $this->randomMachineName();
    $v = $this->randomMachineName();
    $add = [$k => $v . '_0'];
    $this->addAndCheck($add);
    $add = [$k => $v . '_1'];
    $dlData = $this->addAndCheck($add);
    $this->assertNotEquals($v . '_0', $dlData[$k], "D'Oh!  Still has value {$v}_0!");
  }

  /**
   * Test proper handling of sections.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testSectionAdds() {
    $s0 = $this->randomMachineName();
    $s1 = $this->randomMachineName();
    $add = [
      'section0' => $s0,
      'section1' => $s1,
    ];
    $dlData = $this->dataLayer->add($add)->get();
    $this->assertArrayNotHasKey('section0', $dlData, "D'Oh!  Unexpected key :section0: found!");
    $this->assertArrayNotHasKey('section1', $dlData, "D'Oh!  Unexpected key :section1: found!");
    $this->assertArrayHasKey('section', $dlData, "D'Oh!  Expected key :section: not found!");
    $this->assertArrayHasKey(0, $dlData['section'], "D'Oh!  Expected key :section[0]: not found!");
    $this->assertArrayHasKey(1, $dlData['section'], "D'Oh!  Expected key :section[1]: not found!");
    $this->assertEquals($s0, $dlData['section'][0], "D'Oh!  Did not add value for section0!");
    $this->assertEquals($s1, $dlData['section'][1], "D'Oh!  Did not add value for section1!");
  }

  /**
   * Test proper handling of db title.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testDbTitleAdds() {
    $title = $this->randomMachineName();
    $add = [
      'db_title' => $title,
    ];
    $dlData = $this->dataLayer->add($add)->get();
    $this->assertArrayNotHasKey('db_title', $dlData, "D'Oh!  Unexpected key :db_title: found!");
    $this->assertArrayHasKey('db', $dlData, "D'Oh!  Expected key :db: not found!");
    $this->assertArrayHasKey('title', $dlData['db'], "D'Oh!  Expected key :db['title']: not found!");
    $this->assertEquals($title, $dlData['db']['title'], "D'Oh!  Did not add value for db_title!");
  }

  /**
   * Test proper handling of db person.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testDbPersonAdds() {
    $person = $this->randomMachineName();
    $add = [
      'db_person' => $person,
    ];
    $dlData = $this->dataLayer->add($add)->get();
    $this->assertArrayNotHasKey('db_person', $dlData, "D'Oh!  Unexpected key :db_person: found!");
    $this->assertArrayHasKey('db', $dlData, "D'Oh!  Expected key :db: not found!");
    $this->assertArrayHasKey('person', $dlData['db'], "D'Oh!  Expected key :db['person']: not found!");
    $this->assertEquals($person, $dlData['db']['person'], "D'Oh!  Did not add value for db_person!");
  }

  /**
   * Test null/empty/zero inclusions.
   *
   * @covers ::add
   * @covers ::get
   */
  public function testAddNulls() {
    $data = [
      'NULL' => NULL,
      'empty string' => '',
      'zero' => 0,
    ];

    $dlData = $this->dataLayer->add($data)->get();
    foreach ($data as $k => $v) {
      $this->assertArrayNotHasKey($k, $dlData, "D'Oh!  Unexpected key for value {$k} found!");
    }
  }

  /**
   * Add the data and check to see if it was added correctly.
   *
   * @param array $data
   *   The data to add.
   *
   * @return array
   *   The array returned by the DataLayer.
   *
   * @covers ::add
   * @covers ::get
   */
  public function addAndCheck(array $data) {
    $dlData = $this->dataLayer->add($data)->get();

    foreach ($data as $k => $v) {
      $this->assertArrayHasKey($k, $dlData, "D'Oh!  No key for value {$v} found!");
      $this->assertEquals($v, $dlData[$k], "D'Oh!  Did not add value {$v}!");
    }

    return $dlData;
  }

}
