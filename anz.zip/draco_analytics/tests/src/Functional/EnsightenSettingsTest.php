<?php

namespace Drupal\Test\draco_analytics\Functional;

use Drupal\Tests\BrowserTestBase;
use \Drupal\draco_analytics\DataLayer;

/**
 * Tests the Ensighten settings form.
 *
 * @coversDefaultClass \Drupal\draco_analytics\Form\AnalyticsSettingsForm
 *
 * @group draco_analytics
 */
class EnsightenSettingsTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  public static $modules = [
    'draco_analytics',
  ];

  /**
   * DataLayer service.
   *
   * @var mixed
   */
  public $dataLayer;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
    $this->drupalLogin($this->rootUser);
    $this->dataLayer = \Drupal::service('draco_analytics.data');
  }

  /**
   * Test that updating Ensighten settings properly clears the library cache.
   */
  public function testLibraryCacheClear() {

    // Place the script in the head.
    $edit = [
      'ensighten_url' => 'http://example.com/first-file.js',
      'embed_header' => FALSE,
    ];
    $this->drupalPostForm('admin/config/services/draco-analytics', $edit, 'Save configuration');

    $home = $this->drupalGet('<front>');
    $element = new \SimpleXMLElement($home);
    $src = $element->xpath("//html/head/script[@src='" . $edit['ensighten_url'] . "']");
    $this->assertCount(0, $src);

    $src = $element->xpath("//html/body/script[@src='" . $edit['ensighten_url'] . "']");
    $this->assertCount(1, $src);

    // Place the script in the body.
    $edit = [
      'ensighten_url' => 'http://example.com/second-file.js',
      'embed_header' => TRUE,
    ];
    $this->drupalPostForm('admin/config/services/draco-analytics', $edit, 'Save configuration');

    $home = $this->drupalGet('<front>');
    $element = new \SimpleXMLElement($home);
    $src = $element->xpath("//html/head/script[@src='" . $edit['ensighten_url'] . "']");
    $this->assertCount(1, $src);

    $src = $element->xpath("//html/body/script[@src='" . $edit['ensighten_url'] . "']");
    $this->assertCount(0, $src);
  }

  /**
   * Test 404s.
   */
  public function test404s() {
    $tmString = $this->getMetaData($this->randomMachineName());
    $this->assertNotNull($tmString, 'Egads!  No Turner Metadata in <front>!');

    $tmArray = json_decode($tmString, TRUE);
    $good404 = [
      'section' => [
        'error',
        'main',
      ],
      'template_type' => 'adbp:error',
      'content_type' => 'adbp:none',
      'friendly_page_name' => 'error page',
    ];
    $this->assertSame($good404, $tmArray, 'Egads!  404 pages don\'t have correct metadata!');
  }

  /**
   * Get the metadata from a page.
   *
   * @param string $page
   *   The page to get.
   *
   * @return string|null
   *   The metadata, or NULL if none.
   */
  public function getMetaData($page = '<front>') {
    $tmString = NULL;
    $html = $this->drupalGet($page);
    $element = new \SimpleXMLElement($html);
    foreach ($element->xpath('//html/head/script') as $script) {
      if (substr((string) $script, 0, 23) == 'var turner_metadata = {') {
        $tmString = rtrim(substr((string) $script, 22), ';');
      }
    }
    return $tmString;
  }

  /**
   * Config draco_analytics so that the header will be added to the page.
   */
  public function addHeader() {
    $edit = [
      'ensighten_url' => 'http://example.com/my-file.js',
      'embed_header' => TRUE,
    ];
    $this->drupalPostForm('admin/config/services/draco-analytics', $edit, 'Save configuration');
  }

}
