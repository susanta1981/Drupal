# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

### Added

### Changed

### Fixed

## [1.1.0] - 2017-03-10

- Bug fixes, code cleanup, and unit tests written.
- Drupal.org is now used for composer. Legacy version constraints will be
  removed in a future release.

### Added

- Unit tests
- PHPDoc for functions
- Interfaces for all public methods

### Changed

- `hook_page_attachments_alter()` was changed to `hook_page_attachments()`

### Fixed

- `DataLayer::addVideo()` was not saving the incremented video count
- [DRACO-2146](http://tickets.turner.com/browse/DRACO-2146): 404 error pages were not returning correct metadata

## [1.0.1] - yyyy-mm-dd

This version requires database updates and for configuration settings to be
re-exported.

### Added

- [DRACO-2057](http://tickets.turner.com/browse/DRACO-2057): Expose Ensighten as
  a Drupal library. This allows site modules to alter the library definition as
  needed.

### Changed

### Fixed

- The admin configuration form has been cleaned up and moved to
  `admin/config/web-services/draco-analytics`.
- The configuration schema for the module didn't match what was actually saved.
- The Analytics settings form now properly clears caches when changing the URL.
