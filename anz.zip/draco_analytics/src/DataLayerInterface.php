<?php

namespace Drupal\draco_analytics;

/**
 * Interface for DataLayer.
 */
interface DataLayerInterface {

  /**
   * Get the default analytics vars.
   *
   * @return array
   *   The array of defaults.
   */
  public function getDefaults();

  /**
   * Add a set of data to the page's analytics.
   *
   * @param array $data
   *   Data to add.
   *
   * @return DataLayerInterface
   *   The updated DataLayer object.
   */
  public function add(array $data);

  /**
   * Tell draco_analytics that this page includes video.
   *
   * @return DataLayerInterface
   *   The updated DataLayer object.
   */
  public function addVideo();

  /**
   * Get the data to send to the analytics platform.
   *
   * @return array
   *   The array of data to send for analytics.
   */
  public function get();

}
