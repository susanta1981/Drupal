<?php

namespace Drupal\draco_analytics\Form;

use Drupal\Core\Asset\LibraryDiscoveryInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Configure Ensighten JavaScript urls.
 */
class AnalyticsSettingsForm extends ConfigFormBase {

  /**
   * Analytics config object.
   *
   * @var \Drupal\Core\Config\Config
   */
  protected $config;

  /**
   * The string translation service.
   *
   * @var \Drupal\Core\StringTranslation\TranslationInterface
   */
  protected $stringTranslation;

  /**
   * The library discovery service, used to clear caches.
   *
   * @var \Drupal\Core\Asset\LibraryDiscoveryInterface
   */
  protected $libraryDiscovery;

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('string_translation'),
      $container->get('library.discovery')
    );
  }

  /**
   * Analytics settings form constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactory|\Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   A configuration factory containing draco_analytics settings.
   * @param \Drupal\Core\StringTranslation\TranslationInterface $string_translation
   *   The string translation service used for form text.
   * @param \Drupal\Core\Asset\LibraryDiscoveryInterface $library_discovery
   *   The library discovery service, to clear library info caches when settings
   *   are changed.
   */
  public function __construct(ConfigFactoryInterface $config_factory, TranslationInterface $string_translation, LibraryDiscoveryInterface $library_discovery) {
    parent::__construct($config_factory);
    $this->config = $config_factory->get('draco_analytics.settings');
    $this->stringTranslation = $string_translation;
    $this->libraryDiscovery = $library_discovery;
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'draco_analytics.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'draco_analytics.settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config;

    $form['ensighten_url'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Ensighten JavaScript URL'),
      '#default_value' => $config->get('ensighten_url'),
      '#description' => $this->t('Enter the URL to the Ensighten bootstrap file, such as %url.', ['%url' => '//nexus.ensighten.com/turner/tbs-qa/Bootstrap.js']),
    );

    $form['embed_header'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Embed the Ensighten JavaScript in the page header'),
      '#default_value' => $config->get('embed_header'),
      '#description' => $this->t('By default, Ensighten is embedded in the page footer to ensure page performance. Use this option if your site is using Ensighten functionality that requires it to be in the page header.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $this->config('draco_analytics.settings')
      ->set('ensighten_url', $values['ensighten_url'])
      ->set('embed_header', $values['embed_header'])
      ->save();

    $this->libraryDiscovery->clearCachedDefinitions();
  }

}
