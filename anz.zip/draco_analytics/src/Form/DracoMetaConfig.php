<?php
/**
 * Created by PhpStorm.
 * User: a138200
 * Date: 3/21/17
 * Time: 9:34 PM
 */

namespace Drupal\draco_analytics\Form;


use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;


class DracoMetaConfig extends ConfigFormBase {
    /**
     * Analytics config object.
     *
     * @var \Drupal\Core\Config\Config
     */
    protected $config;

    /**
     * {@inheritdoc}
     *
     * @codeCoverageIgnore
     */
    public static function create(ContainerInterface $container) {
        return new static(
            $container->get('config.factory')
        );
    }

    public function __construct(ConfigFactoryInterface $config_factory) {
        parent::__construct($config_factory);
        $this->config = $config_factory->get('draco_analytics.metadata');

    }

    /**
     * {@inheritdoc}
     */
    protected function getEditableConfigNames() {
        return [
            'draco_analytics.metadata',
        ];
    }
    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'draco_analytics.metadata';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config;

        $form['article_author'] = array(
            '#type' => 'textfield',
            '#title' => $this->t('Article Author'),
            '#default_value' => $config->get('article_author'),
        );



        return parent::buildForm($form, $form_state);
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $values = $form_state->getValues();
        $this->config('draco_analytic.metadata')
            ->set('article_author', $values['article_author'])
            //->set('embed_header', $values['embed_header'])
            ->save();

        //$this->libraryDiscovery->clearCachedDefinitions();
    }
}

