<?php

namespace Drupal\draco_analytics;

/**
 * The data layer for Ensighten analytics.
 *
 * @package Drupal\draco_analytics
 */
class DataLayer implements DataLayerInterface {
  protected $data;

  /**
   * DataLayer constructor.
   */
  public function __construct() {
    $this->data = $this->getDefaults();
  }

  /**
   * {@inheritdoc}
   */
  public function getDefaults() {
    return [
      'article_author' => '',
      'article_publish_date' => '',
      'attribution' => '',
      'branding_content_page' => '',
      'branding_social' => '',
      'branding_value' => '',
      'cap_author' => '',
      'cap_content_type' => '',
      'cap_genre' => '',
      'cap_media_type' => '',
      'cap_show_name' => '',
      'cap_topic' => '',
      'cleanurl' => '',
      'content_type' => '',
      'date_viewed' => '',
      'day_viewed' => '',
      'db_person' => '',
      'db_title' => '',
      'edition' => '',
      'events' => '',
      'featured_content' => '',
      'franchise' => '',
      'franchise_partner' => '',
      'friendly_page_name' => '',
      'gallery_name' => '',
      'headline' => '',
      'interaction' => '',
      'media_type' => '',
      'music' => '',
      'mvpd' => '',
      'optimizely' => '',
      'platform_presentation' => '',
      'player_type' => '',
      'playername' => '',
      'presentation_template' => '',
      'search_keyword_value' => '',
      'search_number_results' => '',
      'section0' => '',
      'section1' => '',
      'series_name' => '',
      'special_features' => '',
      'super_franchise' => '',
      'template_type' => '',
      'topic' => '',
      'transaction_id' => '',
      'type_widget' => '',
      'video_category' => '',
      'video_collection' => '',
      'video_count' => 0,
      'video_id' => '',
      'video_opportunity' => '',
      'video_present' => FALSE,
      'video_publish_date' => '',
      'video_segment' => '',
      'video_title' => '',
      'video_type' => '',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function add(array $data) {
    $this->data = array_merge($this->data, $data);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function addVideo() {
    $this->data['video_count']++;
    $this->data['video_present'] = TRUE;
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function get() {
    $data = $this->data;

    $data['section'] = [];
    $data['section'][] = $data['section0'];
    $data['section'][] = $data['section1'];

    $data['db'] = [];
    if ($data['db_title']) {
      $data['db']['title'] = $data['db_title'];
    }
    if ($data['db_person']) {
      $data['db']['person'] = $data['db_person'];
    }

    unset($data['section0'], $data['section1'], $data['db_title'], $data['db_person']);

    // Get rid of empty values.
    return array_filter($data);
  }

}
