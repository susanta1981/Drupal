#!/bin/sh

# This script is needed in order to run standalone unit tests for this module.

cd vendor/drupal
mkdir -p modules
mkdir -p profiles
mkdir -p sites
ln -sf ../autoload.php .
cd ../../
