<?php

// @codingStandardsIgnoreStart

/**
 * Base tasks for setting up a module to test within a full Drupal environment.
 *
 * This file expects to be called from within the module directory, and for a
 * Drupal installation to be located in the parent directory. In other words,
 * this module should be in /modules and not /sites/all/modules or other
 * locations.
 *
 * @class RoboFile
 * @codeCoverageIgnore
 */
class RoboFile extends \Robo\Tasks {

  /**
   * RoboFile constructor.
   */
  public function __construct() {
    // Treat this command like bash -e and exit as soon as there's a failure.
    $this->stopOnFail();
  }

  /**
   * The name of this module.
   */
  const MODULE = 'draco_analytics';

  /**
   * Files which we don't want to copy into the module directory.
   */
  static $excludeFiles = [
    '.',
    '..',
    'vendor',
    'RoboFile.php',
    '.git',
    '.idea',
  ];

  /**
   * Set up the entire Drupal environment.
   */
  public function setup() {
    $this->setupSkeleton();
    $this->setupDrupal();
  }

  /**
   * Set up the Drupal skeleton to test the module.
   */
  public function setupSkeleton() {
    // Copy the constant for easy string concatenation.
    $module = self::MODULE;

    // Copy in our custom phpunit.xml.core.dist file.
    $this->taskFilesystemStack()
      ->copy('phpunit.core.xml.dist', '../../core/phpunit.xml')
      ->run();

    chdir('../../');
    $this->taskExec('composer config repositories.draco composer https://satis.draco.services.dmtio.net')
      ->run();

    // composer config doesn't allow us to set arrays, so we have to do this by
    // hand.
    $config = json_decode(file_get_contents('composer.json'));
    $config->extra->{"merge-plugin"}->include[] = "modules/$module/composer.json";
    file_put_contents('composer.json', json_encode($config));
    // The git checkout includes a composer.lock, and running composer update
    // on it fails for the first time.
    $this->taskFilesystemStack()->remove('composer.lock')->run();

    $this->taskComposerUpdate()
      ->optimizeAutoloader()
      ->run();
    chdir("modules/$module");
  }

  /**
   * Install Drupal.
   */
  public function setupDrupal() {
    $db_url = self::DB_URL;
    $this->drush()
      ->args('site-install', "--db-url=$db_url", '-y')
      ->run();
    $this->taskFilesystemStack()
      ->chown($this->getDocroot() . '/sites/default/files', 'www-data')
      ->run();
  }

  /**
   * Copy files from the root of the repository into the module directory.
   */
  public function copyModuleFiles() {
    $module = self::MODULE;
    $files = scandir(getcwd());
    $files = array_diff($files, self::$excludeFiles);

    $this->taskFilesystemStack()
      ->mkdir("docroot/modules/$module")
      ->run();

    foreach ($files as $file) {
      if (is_dir($file)) {
        $this->taskFilesystemStack()
          ->mirror($file, "docroot/modules/$module/$file")
          ->run();
      }
      else {
        $this->taskFilesystemStack()
          ->copy($file, "docroot/modules/$module/$file")
          ->run();
      }
    }
  }

  /**
   * Return drush with default arguments.
   *
   * @return \Robo\Task\Base\Exec
   *   A drush exec command.
   */
  protected function drush() {
    // Drush needs an absolute path to the docroot.
    $docroot = $this->getDocroot();
    return $this->taskExec('../../vendor/bin/drush')->args('-r', $docroot);
  }

  /**
   * Get the absolute path to the docroot.
   *
   * @return string
   */
  protected function getDocroot() {
    $docroot = (getcwd() . '../');
    return $docroot;
  }

  /**
   * Run PHPUnit and simpletests for the module.
   */
  public function test() {
    chdir('../../');
    $this->phpUnit()
      ->run();
    chdir('modules/' . static::MODULE);
  }

  /**
   * Run unit tests for the module.
   */
  public function testUnit() {
    $this->phpUnit()
      ->option('testsuite', 'unit')
      ->run();
  }

  /**
   * Run tests with code coverage reports.
   */
  public function testCoverage() {
    chdir('../../');
    $this->phpUnit()
      ->option('coverage-clover', '/tmp/clover.xml')
      ->option('coverage-html', '/tmp/coverage-html')
      ->run();
    chdir('modules/' . static::MODULE);
  }

  /**
   * Return a configured phpunit task.
   *
   * @return \Robo\Task\Testing\PHPUnit
   */
  private function phpUnit() {
    return $this->taskPhpUnit('vendor/bin/phpunit')
      ->arg('--verbose')
      ->arg('--debug')
      ->configFile('core/phpunit.xml')
      ->group(static::MODULE);
  }

}
