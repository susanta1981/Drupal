<?php

namespace Drupal\events\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Event entity entities.
 *
 * @ingroup events
 */
class EventEntityDeleteForm extends ContentEntityDeleteForm {


}
