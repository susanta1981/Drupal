<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pool game</title>
	
<!-- Load Bootstrap CSS FROM CDN -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<style>
	body {
  			padding-top: 20px;
  			padding-bottom: 20px;
		}

	.navbar {
  			margin-bottom: 20px;
		}
</style>