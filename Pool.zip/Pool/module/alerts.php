<?php
function writeMsg($tipe){
	if ($tipe=='create.success') {
		$MsgClass = "alert-success";
		$Msg = "<strong>Success!</strong> Data inserted successfully!";	
	} else 
	if ($tipe == 'create.error') {
		$MsgClass = "alert-danger";
		$Msg = "<strong>Oops!</strong> Something went wrong!";
	}
	else 
	if ($tipe == 'update.success') {
		$MsgClass = "alert-success";
		$Msg = "<strong>Success!</strong> Data Updated successfully!";
	}
	else 
	if ($tipe == 'update.error') {
		$MsgClass = "alert-danger";
		$Msg = "<strong>Oops!</strong> Something went wrong!";
	}

echo "<div class=\"alert alert-dismissible ".$MsgClass."\">
  	  <button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button>
  	  ".$Msg."
	  </div>";		  
}
?>