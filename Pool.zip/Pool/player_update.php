<?php 
include "module/header.php";
include "module/alerts.php";
include "config/connect.php"; 

$stmt = $db->prepare('SELECT id, nama, email, hp FROM t_member WHERE id = :id');
$stmt->execute(array(':id' => $_GET['id']));
$data = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
</head>
<body>

<div class="container">
<?php include "module/nav.php"; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="page-header">
            <h1>Player Update</h1>
        </div>
    </div>
</div>

<div class="row">
	<div class="col-md-6">
	<form id="form_input" method="POST">	

<?php  
if(isset($_POST['update']))
{
	
	try {    
    	//insert into database
    	$stmt = $db->prepare('UPDATE t_member SET nama = :nama, email = :email, hp = :hp WHERE id = :id') ;
    	$stmt->execute(array(
    		':nama' => $_POST['nama'],
    		':email' => $_POST['email'],
    		':hp' => $_POST['hp'],
    		':id' => $_GET['id']
    	));
    	writeMsg('update.success');
    
    } catch(PDOException $e) {
        echo $e->getMessage();
    }

//Re-Load Data from DB
$stmt = $db->prepare('SELECT id, nama, email, hp FROM t_member WHERE id = :id');
$stmt->execute(array(':id' => $_GET['id']));
$data = $stmt->fetch();
}
?>

	<div class="form-group">
  		<label class="control-label" for="nama">Full Name</label>
  		<input type="text" class="form-control" name="nama" id="nama" value="<?php echo $data['nama']; ?>" required>
	</div>

	<div class="form-group">
  		<label class="control-label" for="email">Email </label>
  		<input type="email" class="form-control" name="email" id="email" value="<?php echo $data['email']; ?>" required>
	</div>

	<div class="form-group">
  		<label class="control-label" for="hp">Contact Number</label>
  		<input type="text" class="form-control" name="hp" id="hp" value="<?php echo $data['hp']; ?>">
	</div>

	<div class="form-group">
	<input type="submit" value="Update" name="update" class="btn btn-primary">
	<a href="index.php" class="btn btn-danger">Back</a>
	</div>

	</form>
	</div>
</div>

</div>
<?php include "module/footer.php"; ?>
</body>
</html>