<?php

namespace Drupal\manage_product\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use GuzzleHttp\Client;

/**
 * Class GetProductJson.
 */
class GetProductJson extends ControllerBase {

  /**
   * GuzzleHttp\Client definition.
   *
   * @var \GuzzleHttp\Client
   */
  protected $httpClient;

  /**
   * Constructs a new GetProductJson object.
   */
  public function __construct(Client $http_client) {
    $this->httpClient = $http_client;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('http_client')
    );
  }

  /**
   * Printjson.
   *
   * @return string
   *   Return Hello string.
   */
  public function printJson() {
    $request = $this->httpClient->get('http://localhost/drupal8demo/page/json', [
    'auth' => ['admin','admin123']
  ]);
  //print_r($request);
  $response = $request->getBody()->getContents();
  print_r($response);die;
	return [
      '#type' => 'markup',
      '#markup' => $this->t('Implement method: printJson')
    ];
  }

}
