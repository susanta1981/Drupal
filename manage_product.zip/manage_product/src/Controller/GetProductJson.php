<?php

namespace Drupal\manage_product\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Config\ConfigFactory;
use GuzzleHttp\Client;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class GetProductJson.
 */
class GetProductJson extends ControllerBase {

  /**
   * GuzzleHttp\Client definition.
   *
   * @var \GuzzleHttp\Client
   */
  protected $httpClient;
  
  /**
   * Drupal\Core\Config\ConfigFactory definition.
   *
   * @var \Drupal\Core\Config\ConfigFactory
   */
  protected $feedConfig;

  /**
   * Constructs a new GetProductJson object.
   */
  public function __construct(Client $http_client, ConfigFactory $config_factory) {
    $this->httpClient = $http_client;
    $this->feedConfig = $config_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('http_client'),
      $container->get('config.factory')
    );
  }

  /**
   * Printjson.
   *
   * @return string
   *   Return Hello string.
   */
  public function printJson() {
    $url = $this->feedConfig->get('manage_product.feedsettings')->get('source_url');
    $username = $this->feedConfig->get('manage_product.feedsettings')->get('user_name');
    $password = $this->feedConfig->get('manage_product.feedsettings')->get('password');
	$request = $this->httpClient->get($url, ['auth' => [$username, $password]]);
	$this->feedConfig->getEditable('manage_product.feedsettings')
	  ->set('json_data', $request->getBody()->getContents())
	  ->save();
	return new JsonResponse('Saved data');
  }

}
