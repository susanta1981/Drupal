<?php
namespace Drupal\events\Controller;

use Drupal\Core\Controller\ControllerBase;

class EventView extends ControllerBase {

  public function display($event_slug, $abc, $year_slug) {
    $years_data = events_get_years();
    $valid_year = false;
    if (is_numeric($year_slug) && strlen($year_slug) == 4) {
      if (in_array($year_slug, $years_data)) {
        $valid_year = true;
      }
    }
    if ($valid_year) {
      $event_data = events_get_event($year_slug, $event_slug);
      $view_event = \Drupal::entityManager()->getViewBuilder('event_entity');

      return $view_event->view($event_data);
    }

    return array('#markup' => 'No Such Event found');
  }

}